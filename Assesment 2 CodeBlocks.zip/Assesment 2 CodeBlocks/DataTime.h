#pragma once
#ifndef DATETIME_H
#define DATETIME_H

#include <iostream>
#include <fstream>
#include <string>

#include "DATE.h"
#include "Time.h"

using namespace std;

/**
 * @class DateTime
 * @brief encapsulates the date and time class so that they can be used together easly
 *
 * Contains date, time
 *
 * @author Thomas Tregonning-Barwell
 * @version 01
 * @date 30/05/2020 Thomas Tregonning-Barwell, created class, added accessor and mutator methods
 *
 * @author Thomas Tregonning-Barwell
 * @version 02
 * @date 31/05/2020 Thomas Tregonning-Barwell, added operator overloads
 * @todo Nothing so far.
 *
 * @bug My program has no bugs. Well, maybe it has...
 */

class DateTime
{
public:

		/**
		* @brief Default DateTime constructor
		*
		* sets all values of date and month to 0
		*
		*/

	DateTime();

		/**
		* @brief Parameterized DateTime constructor
		*
		* sets the value of date and time to dat and tim
		*
		* @param  Date
		* @param  Time
		*/

	DateTime(Date dat,Time tim);

		/**
		* @brief basic Date accessor method
		*
		* @return Date
		*/

	Date GetDate();

		/**
		* @brief basic Date mutator method
		* @param  Date
		* @return void
		*/

	void SetDate(Date dat);

		/**
		* @brief basic Time accessor method
		*
		* @return Time
		*/

	Time GetTime();

		/**
		* @brief basic Time mutator method
		* @param Time
		* @return void
		*/

	void SetTime(Time tim);

		/**
		* @brief == operater overload
		*
		* checks if right DateTime equal to left DateTime
		*
		* @param DateTime
		*
		*/

	bool operator == (const DateTime&) const;

		/**
		* @brief < operater overload
		*
		* checks if right DateTime is greater than left date
		*
		* @param  DateTime
		*
		*/

	bool operator < (const DateTime&) const;

		/**
		* @brief > operater overload
		*
		* checks if right DateTime is less than left DateTime
		*
		* @param  DateTime
		*
		*/

	bool operator > (const DateTime&) const;

		/**
		* @brief = operater overload
		*
		* sets right DateTime equal to left DateTime
		*
		* @param  DateTime
		*
		*/

	DateTime& operator = (const DateTime& DateTime);


private:
	Date date;
	Time time;
};
#endif // DATE_H
