
#include "Time.h"


Time::Time():hours(0), minutes(0)
{

}

Time::Time(int hour, int minute): hours(hour), minutes(minute)
{

}

int Time::getHours() const
{
	return hours;
}
// checks if its greater than 24
bool Time::setHours(int hour)
{
	if (hour > 24)
	{
		return false;
	}
	else
	{
		hours = hour;
		return true;
	}
}
int Time::getMinutes() const
{
	return minutes;
}
// checks if its less than 16
bool Time::setMinutes(int minute)
{
	if (minute > 59)
	{
		return false;
	}
	else
	{
		minutes = minute;
		return true;
	}

}

std::string Time::getTime() const
{
	return std::to_string(hours) + ":" + std::to_string(minutes);
}

bool Time::operator == (const Time& time) const
{
	if (time.hours == hours)
	{
		if (time.minutes == minutes)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}
bool Time::operator < (const Time& time) const
{
	if (hours < time.hours)
	{
		return true;
	}
	else if (hours == time.hours)
	{
		if (minutes < time.minutes)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}

}

bool Time::operator > (const Time& time) const
{

	if (hours > time.hours)
	{
		return true;
	}
	else if (hours == time.hours)
	{
		if (minutes > time.minutes)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}

}


Time& Time::operator = (const Time& time)
{
	hours = time.hours;
	minutes = time.minutes;

	return *this;
}

