#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <map>
#include <vector>
#include <limits>
#include "DATE.H"
#include "Time.h"
#include "DataTime.h"
#include "Tree.h"

using std::string;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::cin;
using std::map;
using std::vector;

// stores data from the file
typedef struct
{
	Date date;
	Time time;
	float windSpeed;
	float ambientAirTemperature;
	float solarRadiation;

} WindLogType;

// diffrent types of vectors used later in the program
typedef vector<float> floatVec;
typedef vector<string> stringVec;
typedef tree <Date> indexer;
typedef map <DateTime, WindLogType> windLogMap;
typedef vector<WindLogType> windLogVec;

// brakes strings down based on the delimiter
void Tokenizer(string str, char delim, stringVec &value)
{
	int start;
	int end = 0;
	// finds the first spot that isnt the delimiter, if that is not the the end of the string
	while ((start = str.find_first_not_of(delim, end)) != std::string::npos)
	{
		// finds the delimiter
		end = str.find(delim, start);
		// substrings it based on start and end
		value.push_back(str.substr(start, end - start));
	}
}

// Returns the amount of days for each month
int getMonthDay(const int month)
{
	switch (month)
	{
	case 1:
		return 31;
		break;

	case 2:
		return 29;
		break;

	case 3:
		return 31;
		break;

	case 4:
		return 30;
		break;

	case 5:
		return 31;
		break;

	case 6:
		return 30;
		break;

	case 7:
		return 31;
		break;

	case 8:
		return 31;
		break;

	case 9:
		return 30;
		break;

	case 10:
		return 31;
		break;

	case 11:
		return 30;
		break;

	case 12:
		return 31;
		break;

	default:
		return 0;
	}

}

// reads in info from file in to bst
void readIn(istream & input, indexer & tree, windLogMap &map)
{

	// to store windlog values
	WindLogType wind;
	//string array to store values
	stringVec fileInputs;
	// string value to store file lines
	string value;
	//read in first line of the file and discard it
	std::getline(input, value);
	//read lines till no more their are no more lines
	while (std::getline(input, value))
	{
		//break lines in to indviual values
		Tokenizer(value, ',', fileInputs);

		stringVec dateAtime;
		// break date and time appart
		Tokenizer(fileInputs[0], ' ', dateAtime);

		stringVec date;
		// break date into day, month, year
		Tokenizer(dateAtime[0], '/', date);
		// pass date in to wind
		wind.date.SetDay(atoi(date[0].c_str()));
		wind.date.SetMonth(atoi(date[1].c_str()));
		wind.date.SetYear(atoi(date[2].c_str()));
		// insert the date in to the tree
		tree.Insert(wind.date);

		stringVec time;
		// break time into hours and minutes
		Tokenizer(dateAtime[1], ':', time);
		// pass time in to wind
		wind.time.setHours(atoi(time[0].c_str()));
		wind.time.setMinutes(atoi(time[1].c_str()));
		// create new DateTime for BST

		// pass wind speed in to wind
		wind.windSpeed = atof(fileInputs[10].c_str());
		// pass solar radiation in to wind
		wind.solarRadiation = atof(fileInputs[11].c_str());
		// pass ambient air temperature in to wind
		wind.ambientAirTemperature = atof(fileInputs[17].c_str());
		// value is
		DateTime newDateTime(wind.date, wind.time);
		// Insert values for windlong in to the map
		map.insert(std::pair<DateTime,WindLogType>(newDateTime, wind));
		// clear all vectors of data from this line
		fileInputs.clear();
		dateAtime.clear();
		date.clear();
		time.clear();


	}

}

//returns the month number as its string counterpart
string getMonth(const int month)
{
	switch (month)
	{
		case 1:
			return "January";
		break;

		case 2:
			return "February";
		break;

		case 3:
			return "March";
		break;

		case 4:
			return "April";
		break;

		case 5:
			return "May";
		break;

		case 6:
			return "June";
		break;

		case 7:
			return "July";
		break;

		case 8:
			return "August";
		break;

		case 9:
			return "September";
		break;

		case 10:
			return "October";
		break;

		case 11:
			return "November";
		break;

		case 12:
			return "December";
		break;

		default:
			return "Invalid";
	}

}
// find if a month of a year has data
bool findMonth(int days, int month, int year ,indexer &tree)
{
	// search bst for a date within the pramiters
	for (int i = 1 ; i < days; i++)
	{
		Date searchDate(i, month, year);
		if (tree.Search(searchDate))
		{
			return true;
		}
	}
	return false;
}

// returns a vector of floats containg the values of wind speed for the requested year and month
floatVec findWindSpeedValues(int NumberOfDays, int month, int year, windLogMap & map)
{
	// vector to be returned
	floatVec floater;
	// start at 00:00
	int minutes = 0;
	int hours = 0;
	// loop for each day of that month
	Date searchDate(0, month, year);
	Time searchTime(hours, minutes);
	DateTime searchValue(searchDate, searchTime);
	for (int i = 1; i < NumberOfDays; i++)
	{
		//set search data to the current day
		searchDate.SetDay(i);
		searchValue.SetDate(searchDate);
		do
		{
		    // if the key is not in the map catch the exeption
			try
			{
				// add the value of windspeed to the vector
				floater.push_back(map.at(searchValue).windSpeed);
			}
			catch (const std::exception&)
			{

			}
			//change time so that the next map item can be retrived
			minutes = searchValue.GetTime().getMinutes() + 10;
			if (minutes == 60)
			{
				hours = searchValue.GetTime().getHours() + 1;
				minutes = 0;

				if (hours == 24)
				{
					hours = 0;
					minutes = 0;
				}
			}
			// set new time
			Time searchTime(hours, minutes);
			searchValue.SetTime(searchTime);
		// stop when end of the day is reached
		} while (searchValue.GetTime().getHours() != 0 || searchValue.GetTime().getMinutes() != 0);
	}

	// return the values as a Vector<float>
	return floater;
}

// returns a vector of floats containg the values of air temperature for the requested year and month
floatVec findAmbientAirTemperature(int NumberOfDays, int month, int year, windLogMap & map)
{
	// vector to be returned
	floatVec floater;
	// start at 00:00
	int minutes = 0;
	int hours = 0;
	// loop for each day of that month
	Date searchDate(0, month, year);
	Time searchTime(hours, minutes);
	DateTime searchValue(searchDate, searchTime);
	for (int i = 1; i < NumberOfDays; i++)
	{
		//set search data to the current day
		searchDate.SetDay(i);
		searchValue.SetDate(searchDate);
		do
		{
		    // if the key is not in the map catch the exeption
			try
			{
				// add the value of ambient air temperature to the vector
				floater.push_back(map.at(searchValue).ambientAirTemperature);
			}
			catch (const std::exception&)
			{

			}
			//change time so that the next map item can be retrived
			minutes = searchValue.GetTime().getMinutes() + 10;
			if (minutes == 60)
			{
				hours = searchValue.GetTime().getHours() + 1;
				minutes = 0;

				if (hours == 24)
				{
					hours = 0;
					minutes = 0;
				}
			}
			// set new time
			Time searchTime(hours, minutes);
			searchValue.SetTime(searchTime);
			// stop when end of the day is reached
		} while (searchValue.GetTime().getHours() != 0 || searchValue.GetTime().getMinutes() != 0);

	}

	// return the values as a Vector<float>
	return floater;
}

// returns a vector of ints containg the values of solar radiation equal to the postions in values
floatVec findSolarRadiation(int NumberOfDays, int month, int year, windLogMap & map)
{
	// vector to be returned
	floatVec floater;
	// start at 00:00
	int minutes = 0;
	int hours = 0;
	// loop for each day of that month
	Date searchDate(0, month, year);
	Time searchTime(hours, minutes);
	DateTime searchValue(searchDate, searchTime);
	for (int i = 1; i < NumberOfDays; i++)
	{
		//set search data to the current day
		searchDate.SetDay(i);
		searchValue.SetDate(searchDate);
		do
		{
		    // if the key is not in the map catch the exeption
			try
			{
				// add the value of solar radiation to the vector
				floater.push_back(map.at(searchValue).solarRadiation);
			}
			catch (const std::exception&)
			{

			}
			//change time so that the next map item can be retrived
			minutes = searchValue.GetTime().getMinutes() + 10;
			if (minutes == 60)
			{
				hours = searchValue.GetTime().getHours() + 1;
				minutes = 0;

				if (hours == 24)
				{
					hours = 0;
					minutes = 0;
				}
			}
			// set new time
			Time searchTime(hours, minutes);
			searchValue.SetTime(searchTime);
			// stop when end of the day is reached
		} while (searchValue.GetTime().getHours() != 0 || searchValue.GetTime().getMinutes() != 0);

	}

	// return the values as a Vector<float>
	return floater;
}

// check if one float is greater than the other
bool cmpf(float A, float B, float epsilon = 0.005f)
{
	return (fabs(A - B) < epsilon);
}

// find the largest solar radation for a day
float findLargestSolarRadiation(Date StartDate, windLogMap & map)
{
	// largest solar radiation value for that day
	float Largest = 0;
	// start at 00:00
	int minutes = 0;
	int hours = 0;
	//search the for the largest solar radation for the current date
	Time searchTime(hours, minutes);
	DateTime searchValue(StartDate, searchTime);
	do
	{
		 // if the key is not in the map catch the exeption
		try
		{
			if (map.at(searchValue).solarRadiation > Largest)
			{
				Largest = map.at(searchValue).solarRadiation;
			}

		}
		catch (const std::exception&)
		{

		}
		//change time so that the next map item can be retrived
		minutes = searchValue.GetTime().getMinutes() + 10;
		if (minutes == 60)
		{
			hours = searchValue.GetTime().getHours() + 1;
			minutes = 0;

			if (hours == 24)
			{
				hours = 0;
				minutes = 0;
			}
		}
		// set new time
		Time searchTime(hours, minutes);
		searchValue.SetTime(searchTime);
		// stop when end of the day is reached
	} while (searchValue.GetTime().getHours() != 0 || searchValue.GetTime().getMinutes() != 0);
    // return the largest solar radiaton
	return Largest;
}
// returns a vector of ints containg the values of solar radiation equal to the postions in values

vector<Time> findTimesForValue(float value,  Date StartDate, windLogMap & map)
{

    //vector for all the time values that solar radiation is equal to value
	vector<Time> timeVec;
    // start at 00:00
	int minutes = 0;
	int hours = 0;
    //search the day for all the times where solar radiation is equal to value
	Time searchTime(hours, minutes);
	DateTime searchValue(StartDate, searchTime);
	do
	{
	     // if the key is not in the map catch the exeption
		try
		{
		    // compare to value
			if (cmpf(map.at(searchValue).solarRadiation, value))
			{
			    // if its the same add time to vector
				timeVec.push_back(map.at(searchValue).time);
			}

		}
		catch (const std::exception&)
		{

		}
		//change time so that the next map item can be retrived
		minutes = searchValue.GetTime().getMinutes() + 10;
		if (minutes == 60)
		{
			hours = searchValue.GetTime().getHours() + 1;
			minutes = 0;

			if (hours == 24)
			{
				hours = 0;
				minutes = 0;
			}
		}
		// set new time
		Time searchTime(hours, minutes);
		searchValue.SetTime(searchTime);
		// stop when end of the day is reached
	} while (searchValue.GetTime().getHours() != 0 || searchValue.GetTime().getMinutes() != 0);
    // return the vector
	return timeVec;

}

//wright the average and standard devation for wind speed and ambient air temperature plus the total solar radiation to a csv
void wrighToFile(int year, floatVec averageWindSpeed, floatVec WindSpeedStdev, floatVec averageAmbientTemperature, floatVec AmbientTemperatureStdev, floatVec SolarRadiation)
{
	cout << endl;
	cout <<"Wrighting to file"<< endl;
	cout << endl;
	std::ofstream flam("WindTempSolar.csv");
	bool yearData = false;
	flam << year;
	flam << "\n";

	// check if the given year has any data
	for (int i = 0; i < 12; i++)
	{
		if (averageWindSpeed[i] != -1)
		{
			yearData = true;
		}

		if (averageAmbientTemperature[i] != -1)
		{
			yearData = true;
		}

		if (SolarRadiation[i] != -1)
		{
			yearData = true;
		}

	}
	// if there is no data for that year
	if (!yearData)
	{
		flam << "No Data";
	}
	else
	{
		// for each month
		for (int i = 0; i < 12; i++)
		{
			// wright only if that month has values
			flam << getMonth(i + 1);
			flam << ": ";
			if (averageWindSpeed[i] != -1)
			{
				flam.precision(3);
				flam << ",";
				flam << averageWindSpeed[i];
				flam << "(";
				flam << WindSpeedStdev[i];
				flam << ")";

			}

			if (averageAmbientTemperature[i] != -1)
			{
				flam.precision(3);
				flam << ",";
				flam << averageAmbientTemperature[i];
				flam << "(";
				flam << AmbientTemperatureStdev[i];
				flam << ")";
			}

			if (SolarRadiation[i] != -1)
			{
				flam.precision(3);
				flam << ",";
				flam << SolarRadiation[i];
			}
			flam << "\n";
		}

	}


}

//cacualates the avarage for a vector
template <class T>
T CalculateAvarage( const vector<T> & array)
{

		float totalAddition = 0;

		for (int i = 0; i < array.size(); i++)
		{
			totalAddition += array[i];
		}

		return totalAddition / array.size();

}

//cacualates the total for a vector
template <class T>
T CalculateTotal(const vector<T> & array)
{
	float totalAddition = 0;

	for (int i = 0; i < array.size(); i++)
	{
		totalAddition += array[i];
	}

	return totalAddition;
}

//cacualates the standand deviation for a vector
template <class T>
T CalculataStandandDeviation(const vector<T> & array, T avarage)
{

		int sum = 0;

		for(int i = 0; i < array.size(); i++)
		{
			sum += (array[i] - avarage) * (array[i] - avarage);

		}

		return std::sqrt( sum / (array.size() - 1));

}


int main()
{
	// file stream for list of CSVs
	ifstream Data;
	// file stream for CSVs
	ifstream MetDataFile;
	// Name of CSV file
	string FileName;
	// contains the first day of every month for eaxh year
	indexer tree;
	// contains the values form the csv
	windLogMap map;

	// open file with CSV names
	Data.open("Data\\met_index.txt");
	// if the program cant find it close the program
	if (!Data.is_open())
	{
		cout << "location of data files could not be found." << endl;
		Data.close();
		return -1;
	}
	// for each CSV
	while (getline(Data, FileName))
	{

		MetDataFile.open("Data\\" + FileName);
		// if file cant be found
		if (!MetDataFile.is_open())
		{
			cout << "File not found" << endl;

		}
		// read file in to BST and MAP
		else
		{
			readIn(MetDataFile, tree, map);
		}
		MetDataFile.close();
	}
	Data.close();
    cout << endl;
	bool loopBraker = false;

	// run till the user presses quit
	while (loopBraker == false)
	{
		cout << "Enter 1 for average wind speed and standard deviation " << endl <<
			"Enter 2 for average ambient air temperature and standard deviation " << endl <<
			"Enter 3 for total solar radiation in kWh / m2 " << endl <<
			"Enter 4 to print average and standard deviation for wind speed and ambient air temperature and total solar radiation to CSV " << endl <<
			"Enter 5 get highest solar radiation for a day" << endl <<
			"Enter 6 to quit " << endl;
			int option = 0;

			cin >> option;
			// if user enters invalid value
			if (cin.fail())
			{
				cout << "That is not a number" << endl;
				// flush cin
				cin.clear();
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			}
			else
			{
				// if the number entered is a valid option
				if (option > 0 && option < 7)
				{
					//print the average wind speed and standard devation for a given month
					if (option == 1)
					{
						cout << "Please enter a year: ";
						int year;
						cin >> year;
                        cout << endl;
						if (cin.fail())
						{
							cout << "That is not a number" << endl;
							// flush cin
							cin.clear();
							cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                            cout << endl;
						}
						else
						{
							cout << "Please enter a month: ";
							int month;
							cin >> month;
                            cout << endl;
							if (cin.fail())
							{
								cout << "That is not a number" << endl;
                                cout << endl;
								// flush cin
								cin.clear();
								cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
							}
							else
							{
								// look for the max time for that

								cout << endl;
								// check that the system contains values for
								if (findMonth(getMonthDay(month), month, year, tree))
								{
									// set the precision of the printed values
									cout.precision(3);
									// get values of wind speed for that month
									floatVec windspeed = findWindSpeedValues(getMonthDay(month), month, year, map);
									// caculate average
									float averageWindSpeed = (CalculateAvarage(windspeed)* 3.6);
									// caculate standard devation
									float standandDeviationWindSpeed = CalculataStandandDeviation(windspeed, averageWindSpeed);
									//print

									cout << getMonth(month) << " " << year << ":" << endl << "Average Speed: " << averageWindSpeed << "km/h " << endl << "Sample stdev: " << standandDeviationWindSpeed << endl;

								}
								// if their are no data for that month
								else
								{

									cout << getMonth(month) << " " << year <<": No Data " << endl;

								}
								cout << endl;

							}

						}

					}
					//print the average ambient air temperature and standard devation for a given year
					if (option == 2)
					{
						cout << "Please enter a year:";
						int year = 0;
						cin >> year;
                        cout << endl;
						if (cin.fail())
						{
							cout << "That is not a number" << endl;
                            cout << endl;
							// flush cin
							cin.clear();
							cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
						}
						else
						{
							cout << endl;
							cout << year << endl;
							for (int i = 1; i < 13; i++)
							{
								// if there are values for that month
								if (findMonth(getMonthDay(i), i, year, tree))
								{
									// set the precision of the printed values
									cout.precision(3);
									// get values of ambient air temperature for that month
									floatVec ambientAirTemperature = findAmbientAirTemperature(getMonthDay(i), i, year, map);
									// caculate average
									float averageAmbientAirTemperature = CalculateAvarage(ambientAirTemperature);
									// caculate standard devation
									float standandDeviationAmbientAirTemperature = CalculataStandandDeviation(ambientAirTemperature, averageAmbientAirTemperature);
									//print
									cout << getMonth(i) << ": average: " <<  averageAmbientAirTemperature << " degrees C, stdev: " << standandDeviationAmbientAirTemperature << endl;
								}
								// if their are no data for that month
								else
								{
									cout << getMonth(i) << ": No Data" << endl;
								}
							}
							cout << endl;

						}
					}
					//print the total solar radiation for a given year
					if (option == 3)
					{
						cout << "Please enter a year:";

						int year = 0;
						cin >> year;
                        cout << endl;
						if (cin.fail())
						{
							cout << "That is not a number" << endl;
                            cout << endl;
							// flush cin
							cin.clear();
							cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
						}
						else
						{
							cout << endl;
							cout << year << endl;
							for (int i = 1; i < 13; i++)
							{
                                // if there are values for that month
								if (findMonth(getMonthDay(i), i, year, tree))
								{
									// get values of solar radiation for that month
									floatVec solarRadiation = findSolarRadiation(getMonthDay(i), i, year, map);
									// calculate total
									float totalSolarRadiation = ((CalculateTotal(solarRadiation)/6)/1000);
									// set the precision of the printed values
									cout.precision(3);
									// print
									cout << getMonth(i) << ": " << totalSolarRadiation << " kWh/m^2 " << endl;
								}
								// if their are no data for that month
								else
								{
									cout << getMonth(i) << ": No Data " << endl;
								}
							}
							cout << endl;

						}

					}
					// prints all relevant average's,standard devations and totals to a csv
					if (option == 4)
					{
						cout << "Please enter a year:";

						int year = 0;
						cin >> year;
                        cout << endl;
						if (cin.fail())
						{
							cout << "That is not a number" << endl;
                            cout << endl;
							// flush cin
							cin.clear();
							cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
						}
						else
						{
							floatVec averageWindSpeed;
							floatVec windSpeedStdev;
							floatVec averageAmbientAirTemperature;
							floatVec ambientAirTemperatureStdev;
							floatVec totalSolarRadiation;
                            // for each month
							for (int i = 1; i < 13; i++)
							{
								// if there are values for that month
								if (findMonth(getMonthDay(i), i, year, tree))
								{	// get relevant values for each month
									floatVec windspeed = findWindSpeedValues(getMonthDay(i), i, year, map);
									floatVec ambientAirTemperature = findAmbientAirTemperature(getMonthDay(i), i, year, map);
									floatVec solarRadiation = findSolarRadiation(getMonthDay(i), i, year, map);
									// calculate for wind speed
									averageWindSpeed.push_back((CalculateAvarage(windspeed)* 3.6));
									windSpeedStdev.push_back(CalculataStandandDeviation(windspeed, averageWindSpeed[i - 1]));
									// calculate for ambient air temperature
									averageAmbientAirTemperature.push_back(CalculateAvarage(ambientAirTemperature));
									ambientAirTemperatureStdev.push_back(CalculataStandandDeviation(ambientAirTemperature, averageAmbientAirTemperature[i - 1]));
									// calculate for solar radiation
									totalSolarRadiation.push_back(((CalculateTotal(solarRadiation) / 6) / 1000));
								}
								// give it -1 so that other methods know they are empty
								else
								{
									 averageWindSpeed.push_back(-1);
									 windSpeedStdev.push_back(-1);
									 averageAmbientAirTemperature.push_back(-1);
									 ambientAirTemperatureStdev.push_back(-1);
									 totalSolarRadiation.push_back(-1);
								}


							}
							// wirght all info to file
							wrighToFile(year, averageWindSpeed, windSpeedStdev, averageAmbientAirTemperature, ambientAirTemperatureStdev, totalSolarRadiation);


						}

					}
					// quit the program
					if (option == 5)
					{
					    // get date
						cout << "Please enter a date in d/m/yyyy format " << endl;
						string input;
						cin >> input;
                        cout << endl;
						// break date in to days, months, years
						stringVec date;
						Tokenizer(input, '/', date);
						// if the date does not have all the values
						if (date.size() != 3)
						{
							cout << "That is not a valid format" << endl;

						}
						else
						{
						    cout << endl;
							try
							{
							    // get the total days for that month
								int totalDays = getMonthDay(atoi(date[1].c_str()));
								// check that the user has enterd a vaild month
								if (totalDays >  0)
								{
								    //check that day value is valid
									if (totalDays >= atoi(date[0].c_str()) && atoi(date[0].c_str()) > 0)
									{
									    // create new date
										Date newDate(atoi(date[0].c_str()), atoi(date[1].c_str()), atoi(date[2].c_str()));
                                        // search tree for that date
										if (tree.Search(newDate))
										{
                                             // find largest solar radiation
											float largestSolarRadiation = findLargestSolarRadiation(newDate, map);
											// find times largest solar radiation was recored
											vector<Time> largestSolarRadiationTimes = findTimesForValue(largestSolarRadiation, newDate, map);
											// print largest solar radiation and times it was recorded
											cout << "Date: " << newDate.getDate() << endl;
											cout << "High solar radiation for the day: " << largestSolarRadiation << " W/m2" << endl;
											cout << "Time:" << endl;
											for (int i = 0; i < largestSolarRadiationTimes.size(); i++)
											{
												cout << largestSolarRadiationTimes[i].getTime() << endl;
											}
										}
										else
										{
											cout << "That date is not in the system" << endl;

										}
									}
									// if month value is invalid
									else
									{
										cout << "That is an invalid date" << endl;

									}

								}
								else
								{
									cout << " That is an invalid date" << endl;

								}
								// program asumes that each month has a full set of values
								// check the day is within exepable range
								// and month


							}
							// if date cannot be turned in to a number
							catch (...)
							{
								cout << " That is an invalid date" << endl;
							}


						}
						cout << endl;
					}
					// quit the program
					if (option == 6)
					{

						cout << "Quiting";
						loopBraker = true;
					}
				}
				// if the number is not a valid option
				else
				{
					cout << "That is not a valid number" << endl;
				}

			}
	}
	return 0;
}

