#pragma once
#include <sstream>
using std::cout;
using std::endl;

template <class T>
class tree
{
	/**
	* @class Tree
	* @brief Templated Binary search tree
	*
	*
	* @author Thomas Tregonning-Barwell
	* @version 01
	* @date 15/05/2020 Thomas Tregonning-Barwell, created class tree
	*
	* @author Thomas Tregonning-Barwell
	* @version 01
	* @date 15/05/2020 Thomas Tregonning-Barwell, created class tree
	*
	* @todo Make Tree self balanceing.
	*
	* @bug My program has no bugs. Well, maybe it has...
	*/

	
			/**
			* @brief node Struct 
			*
			* contains: 
			* The value for each node of the tree - value
			* A pointer to the left node - LNode
			* A pointer to the right node - RNode
			*
			*/
		struct node
		{
			T value;
			node * LNode;
			node * RNode;
		};

	public:
			/**
			* @brief  Default tree Constructor
			*
			* sets the root of the tree to nulPtr
			*
			*/

		tree();

			/**
			* @brief Default Tree Deconstructor
			*
			* calls the destroy method
			* will destroy the tree if it goes out of scope
			*
			*/

		~tree();

			/**
			* @brief Tree Copy Constructor
			*
			* calls the copy method
			* will set the new tree its called on equal to the passed in tree
			*
			* @param newTree -  Tree containg values to be copyed
			*/

		tree(tree & newTree);

			/**
			* @brief = operator tree Constructor
			* calls the copy method
			* Sets the tree that method was called on equal to the tree passed in
			*
			* @param newTree -  Tree containg values to be copyed 
			*/

		const tree & operator = (const tree & newTree);

			/**
			* @brief Iterative Insert Method 
			*
			* Adds passed in value to the tree
			* Does not balance the tree
			*
			* @param value - Value to be added
			* @return bool - If value was allready inside the tree return false
			*/

		bool Insert(T &value);

			/**
			* @brief DeleteTree Method
			*
			* calls the destroy method which will destroy the tree
			*
			*/
	
		void DeleteTree();

			/**
			* @brief Iterative Search Method
			*
			* checks to see if the tree contains a value
			* Takes in a value of type T by refrence
			* If it finds the search item it sets searchItem equal to the value stored in the tree
			*
			* @param *value - pointer to value to be added
			* @return bool - If value was found inside the tree return true
			*/

		bool Search(T &searchItem);

			
			/**
			* @brief preOrderTraversal method 
			*
			* traverses the tree, method called before moveing to next node
			* 
			* @param *funk - pointer to method called on each node of the tree, Takes a value of type T by refrence
			*
			*/



		void preOrderTraversal(void(*funk)(T &));
			/**
			* @brief inOrderTraversal Method
			*
			* traverses the tree, left node visited before the method is called
			*
			* @param *funk - pointer to method called on each node of the tree, Takes a value of type T by refrence
			*
			*/

		void inOrderTraversal(void(*funk)(T &));

			/**
			* @brief postOrderTraversal Method
			*
			* traverses the tree, both nodes visited before the method is called
			*
			* @param *funk - pointer to method called on each node of the tree, Takes a value of type T by refrence
			*
			*/


		void postOrderTraversal(void(*funk)(T &));

	private:

			/**
			* @brief copyTree Method
			*
			* Recursive method, loops through the tree and 
			* sets all nodes in the one tree equal to the other
			*
			* @param copyRoot- By refrence pointer to node haveing its value changed
			* @param mainRoot - Pointer to node containg value
			*/

		void copyTree(node * &copyRoot, node * mainRoot);

			/**
			* @brief destroy Method
			*
			* Recursive method, loops through the tree and
			* deletes all nodes
			*
			* @param currentNode - By refrence pointer to node being deleted
			*/

		void destroy(node * &currentNode);

			/**
			* @brief preOrder Method
			*
			* preOrder traversal recursive method, loops through the tree and passes the value of each node into the function pointer
			*
			* @param currentLeaf - pointer to current node
			* @param funk - pointer to function being called on each node
			*/
		void preOrder(node *currentLeaf, void(*funk)(T & value)) const;

			/**
			* @brief inOrder Method
			*
			* preOrder traversal recursive method, loops through the tree and passes the value of each node into the function pointer
			*
			* @param currentLeaf - pointer to current node
			* @param funk - pointer to function being called on each node
			*/

		void inOrder(node *currentLeaf, void(*funk)(T & value)) const;

			/**
			* @brief postOrder Method
			*
			* preOrder traversal recursive method, loops through the tree and passes the value of each node into the function pointer
			*
			* @param currentLeaf - pointer to current node
			* @param funk - pointer to function being called on each node
			*/

		void postOrder(node *currentLeaf, void(*funk)(T & value)) const;
		
		node * root;/// Stating Root of the tree

};

template <class T>
tree<T>::tree()
{
	root = nullptr;
}

template <class T>
tree<T>::~tree()
{
	destroy(root);
}

template <class T>
tree<T>::tree(tree & newTree)
{
	// if your copying a empty tree
	if (newTree.root == nullptr)
	{
		root = nullptr;
	}
	else
	{
		copyTree(root, newTree.root);
	}

}

template <class T>
const tree<T> & tree<T>::operator = (const tree<T> & newTree)
{
	// if this tree is not equals to the passed in tree
	if (this != &newTree)
	{
		//if the tree its not empty 
		if (root != nullptr)
		{
			// reset the tree
			destroy(root);
		}
		// if the passed in tree is empty 
		if (newTree.root == nullptr)
		{
			// make this tree empty
			root = nullptr;
		}
		// set this tree equal to the passed in tree
		else
		{
			copyTree(root, newTree.root);
		}
	}
	// return method so it can be stacked
	return *this;
}

template <class T>
bool tree<T>::Insert(T &value)
{
	// the current node in the tree
	node * currentNode;
	// node last looked at
	node * PreviosNode = nullptr;
	// node to be assigend to the tree
	node * NewNode;

	// create the node being added to the tree
	NewNode = new node;
	// value stored in node
	NewNode->value = value;
	NewNode->LNode = nullptr;
	NewNode->RNode = nullptr;
	// if tree empty
	if (root == nullptr)
	{
		root = NewNode;
	}
	else
	{
		// start from the root
		currentNode = root;
		//loop untill you find an empty node 
		while (currentNode != nullptr)
		{
			// keep track of the last node looked at
			PreviosNode = currentNode;
			// if the value being added is already in the tree
			if (currentNode->value == value)
			{
				return false;
			}
			// if value being added is smaller than the current node value
			else if (currentNode->value > value)
			{
				// go left
				currentNode = currentNode->LNode;
			}
			// if value being added is greater than the current node value
			else
			{
				// go right
				currentNode = currentNode->RNode;
			}

		}
		// when an empty node is found
		// if value being added is smaller than the current node value
		if (PreviosNode->value > value)
		{
			// set new node as left
			PreviosNode->LNode = NewNode;

		}
		// if value being added is greater than the current node value
		else
		{
			// set new node as right
			PreviosNode->RNode = NewNode;

		}

	}
}

template <class T>
void tree<T>::DeleteTree()
{
	destroy(root);
}

template <class T>
bool tree<T>::Search(T &searchItem)
{
	// current node being looked at
	node *currentLeaf;
	bool found = false;
	// if the tree is not empty
	if (root != nullptr)
	{
		// start at the root
		currentLeaf = root;
		// while the value has not been found and the current leaf has a node
		while (currentLeaf != nullptr && !found)
		{
			// check if values are the same 
			if (currentLeaf->value == searchItem)
			{
				// set the search item equal to the found value
				searchItem = currentLeaf->value;
				found = true;
			}
			// if value smaller go left
			else if (currentLeaf->value > searchItem)
			{
				currentLeaf = currentLeaf->LNode;
			}
			// if value bigger go right
			else
			{
				currentLeaf = currentLeaf->RNode;
			}
		}
	}
	return found;
}

template <class T>
void tree<T>::preOrderTraversal(void(*funk)(T &))
{
	preOrder(root, *funk);
}

template <class T>
void tree<T>::inOrderTraversal(void(*funk)(T &))
{
	inOrder(root, *funk);

}

template <class T>
void tree<T>::postOrderTraversal(void(*funk)(T &))
{
	postOrder(root, *funk);
}

template <class T>
void tree<T>::copyTree(node * &copyRoot, node * mainRoot)
{
	// check node is not empty before copying 
	if (mainRoot == nullptr)
	{
		// if it is then set the copyed node to null
		copyRoot = nullptr;
	}
	else
	{
		// set node equal to the equivalent node in the tree
		copyRoot = new node;
		copyRoot->value = mainRoot->value;
		copyTree(copyRoot->LNode, mainRoot->LNode);
		copyTree(copyRoot->RNode, mainRoot->RNode);

	}

}
template <class T>
void tree<T>::destroy(node * &currentNode)
{
	// if the node is not empty 
	if (currentNode != nullptr)
	{
		// call self on both attching branches 
		destroy(currentNode->LNode);
		destroy(currentNode->RNode);
		// delete this leaf
		delete currentNode;
		// point current pointer at null
		currentNode = nullptr;
	}
}

template <class T>
void tree<T>::preOrder(node *currentLeaf, void(*funk)(T & value)) const
{
	// if the node is not empty
	if (currentLeaf != nullptr)
	{
		// call method pointer on current node 
		(*funk)(currentLeaf->value);
		// call self on both attching branches 
		preOrder(currentLeaf->LNode, *funk);
		preOrder(currentLeaf->RNode, *funk);
	}
}

template <class T>
void tree<T>::inOrder(node *currentLeaf, void(*funk)(T & value)) const
{
	// if the node is not empty
	if (currentLeaf != nullptr)
	{
		// call on left branch
		inOrder(currentLeaf->LNode, *funk);
		// call method pointer on current node
		(*funk)(currentLeaf->value);
		// call on right branch
		inOrder(currentLeaf->RNode, *funk);
	}
}

template <class T>
void tree<T>::postOrder(node *currentLeaf, void(*funk)(T & value)) const
{
	// if the node is not empty
	if (currentLeaf != nullptr)
	{
		// call self on both attching branches 
		postOrder(currentLeaf->LNode, *funk);
		postOrder(currentLeaf->RNode, *funk);
		// call method pointer on current node
		(*funk)(currentLeaf->value);
	}
}


