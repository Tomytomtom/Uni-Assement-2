#include <iostream>
#include "../Date.h"
using namespace std;

int main()
{
    Date da;
    Date dat(16,3,2000);
    Date date[3];
    date[0].SetDay(19);
    date[1].SetMonth(4);
    date[2].SetYear(1990);

    cout << dat.GetDay() << " " <<  dat.GetMonth() << " " <<  dat.GetYear() << endl;
    cout << date[0].GetDay() << " " <<  date[1].GetMonth() << " " <<  date[2].GetYear() << endl;
    cout << dat.getDate() << endl;

    Date DateOne(18, 12, 2000);
	Date DateTwo(18, 11, 2000);
	Date DateThree(18, 12, 1900);
	Date DateFor(16, 12, 2000);
	Date DateFive(18, 12, 2000);

	if (DateOne == DateFive)
	{
		cout << "value the same " << endl;
	}

	if (DateOne == DateFor)
	{
		cout << "value the same " << endl;
	}

	if (DateTwo < DateOne)
	{
		cout << "Greater " << endl;
	}

	if (DateThree < DateFive)
	{
		cout << "Greater" << endl;
	}

	if (DateFor < DateFive)
	{
		cout << "Greater" << endl;
	}

	if (DateOne > DateTwo)
	{
		cout << "Lesser " << endl;
	}

	if (DateFive > DateThree)
	{
		cout << "Lesser" << endl;
	}

	if (DateFive > DateFor)
	{
		cout << "Lesser" << endl;
	}

    da = DateOne;
    cout << da.getDate() << endl;

    return 0;
}
