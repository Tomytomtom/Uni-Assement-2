#ifndef TIME_H
#define TIME_H

#include <iostream>
#include <string>


class Time
{

	/**
	* @class Time
	* @brief Contains Time value
	*
	* Contains hours and minutes
	*
	* @author Thomas Tregonning-Barwell
	* @version 01
	* @date 19/04/2020 Thomas Tregonning-Barwell, created class, added accessor and mutator methods
	* @author Thomas Tregonning-Barwell
	*
	* @author Thomas Tregonning-Barwell
	* @version 01
	* @date 20/05/2020 Thomas Tregonning-Barwell, operatior overloads
	* @author Thomas Tregonning-Barwell
	*
	*
	* @todo Nothing so far.
	*
	* @bug My program has no bugs. Well, maybe it has...
	*/

public:

		/**
		* @brief  Default Time constructor
		*
		* sets the value of hours and minutes to 0
		*
		*/
	Time();
		/**
		* @brief Parameterized Time constructor
		*
		* sets the value of hours and minutes to the respecive parameter values
		*
		* @param  day
		* @param  month
		* @param  year
		*
		*/
	Time(int hour, int minute);

		/**
		* @brief basic hours accessor method
		*
		* @return int
		*/

	int getHours() const;

		/**
		* @brief basic hours mutator method
		* Checks if hours is greater than 24
		* @param hour
		* @return bool
		*/

	bool setHours(int hour);

		/**
		* @brief basic minutes accessor method
		*
		* @return int
		*/

	int getMinutes() const;

		/**
		* @brief basic minute mutator method
		* checks to see if minutes less than 60
		* @param hour
		* @return bool
		*/

	bool setMinutes(int minute);

		/**
		* @brief returns time as a string
		* returns the time in 24 hour time
		* @return string
		*/

	std::string getTime() const;

		/**
		* @brief == operater overload
		*
		* checks if right time is equal to left time
		*
		* @param  Time
		*/

	bool operator == (const Time&) const;

		/**
		* @brief < operater overload
		*
		* checks if right time is greater than left time
		*
		* @param  Time
		*/

	bool operator < (const Time&) const;

		/**
		* @brief > operater overload
		*
		* checks if right time is less than left time
		*
		* @param  Time
		*
		*/


	bool operator > (const Time&) const;

		/**
		* @brief = operater overload
		*
		*  sets right time equal to left time
		*
		* @param  Time
		*/


	Time& operator = (const Time&);

private:
	int hours; /// stores hours
	int minutes; /// stores minutes
};
#endif
