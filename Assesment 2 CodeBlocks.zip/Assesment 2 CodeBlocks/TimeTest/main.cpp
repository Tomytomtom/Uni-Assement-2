#include <iostream>
#include "../Time.h"
using namespace std;

int main()
{
    Time ti;
    Time tim(16,30);
    Time time[2];
    time[0].setHours(19);
    time[1].setMinutes(40);

    cout << tim.getHours() << " " <<  tim.getMinutes()  << endl;
    cout << time[0].getHours() << " " <<  time[1].getMinutes() << endl;
    cout << tim.getTime() << endl;


    Time TimeOne(18, 12);
	Time TimeTwo(18, 11);
	Time TimeThree(19, 12);
	Time TimeFor(18, 12);


	if (TimeOne == TimeFor)
	{
		cout << "value the same " << endl;
	}

	if (TimeOne == TimeThree)
	{
		cout << "value the same " << endl;
	}

	if (TimeTwo < TimeOne)
	{
		cout << "Greater " << endl;
	}

	if (TimeThree < TimeTwo)
	{
		cout << "Greater" << endl;
	}

	if (TimeFor < TimeFor)
	{
		cout << "Greater" << endl;
	}

	if (TimeOne > TimeTwo)
	{
		cout << "Lesser " << endl;
	}


    ti = TimeOne;
    cout << ti.getTime() << endl;

    return 0;
}
