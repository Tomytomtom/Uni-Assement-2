#include <iostream>
#include <fstream>
#include "../Tree.h"
#include "../DATE.H"
#include "STLVector.h"

typedef STLVector<string> stringVec;
void Tokenizer(string str, char delim, stringVec &value)
{
	int start;
	int end = 0;
	// finds the first spot that isnt the delimiter, if that is not the the end of the string
	while ((start = str.find_first_not_of(delim, end)) != std::string::npos)
	{
		// finds the delimiter
		end = str.find(delim, start);
		// substrings it based on start and end
		value.addValue(str.substr(start, end - start));
	}
}



ostream & operator << (ostream & Output, Date& date)
{
	Output << date.getDate() << '\n';
	return Output;
}
// reads in infomation from csv in to windLog
istream & operator >>(istream & input, tree<Date> &newBST)
{
	//string array to store values
	stringVec fileInputs;
	// string value to store file lines
	string value;
	//read in first line of the file and discard it
	std::getline(input, value);
	//read lines till no more their are no more lines
	while (std::getline(input, value))
	{
		//break lines in to indviual values
		Tokenizer(value, ',', fileInputs);

		stringVec dateAtime;
		// break date and time appart
		Tokenizer(fileInputs[0], ' ', dateAtime);

		stringVec date;
		// break date into day, month, year
		Tokenizer(dateAtime[0], '/', date);
		// pass date in to wind
		Date newDate(atoi(date[0].c_str()), atoi(date[1].c_str()), atoi(date[2].c_str()));
		newBST.Insert(newDate);
		fileInputs.clear();
		dateAtime.clear();
		date.clear();

	}
	return input;
}

void Treversal(Date &value)
{
	cout << value << endl;
}

int main()
{

    tree<Date> newBST;
	std::ifstream in("MetData_Mar01-2014-Mar01-2015-ALL.csv");
	in >> newBST;

	cout << "Main Tree" << endl;
	cout << "Pre Order" << endl;
	newBST.preOrderTraversal(Treversal);
	cout << "In Order" << endl;
	newBST.inOrderTraversal(Treversal);
	cout << "Post Order" << endl;
	newBST.postOrderTraversal(Treversal);

	Date searchDate(31,10,2014);
	if (newBST.Search(searchDate))
	{
		cout << "value was found " << endl;
	}
	else
	{
		cout << "value was found " << endl;
	}

	tree<Date> newTree = newBST;
	newBST.DeleteTree();

	cout << "Copied Tree" << endl;
	cout << "Pre Order" << endl;
	newTree.preOrderTraversal(Treversal);
	cout << "In Order" << endl;
	newTree.inOrderTraversal(Treversal);
	cout << "Post Order" << endl;
	newTree.postOrderTraversal(Treversal);

	Date newSearchDate(31, 10, 2014);
	if (newTree.Search(newSearchDate))
	{
		cout << "value was found " << endl;
	}
	else
	{
		cout << "value was found " << endl;
	}
	newTree.DeleteTree();

}
