#pragma once
#ifndef STLVECTOR_H
#define STLVECTOR_H
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <vector>


/**
 * @brief template class Vector
 *
 * Vector Template that encapsulates a dynamic array.
 * Has full CRUD functionality
 *
 * @author Thomas Tregonning-Barwell
 * @version 01
 * @date 30/03/2020 Thomas Tregonning-Barwell, created class, added accessor and mutator methods
 *
 * @todo vector needs to be able to check to see if their is room on the heap.
 *
 * @bug None as far as im aware
 */

template <class T>
class STLVector
{

public:

	/**
	* @brief  Default Vector Constructor
	*
	* assigns vec a new dinamic array of size ten
	* the array is of type template
	* size is set to ten aswell
	*/
	STLVector()
	{

	}

	/**
	* @brief Copy Vector Constructor
	*
	* used to copy the values of one vector in to another
	* calls the copy method
	* @param constant Vector passed by refrence
	*/

	STLVector(const STLVector & vector)
	{
		vec = vector.vec;
	}

	/**
	* @brief Vector deconstructor
	*
	* used to delete the array off the heap
	*
	*/

	~STLVector()
	{

	}

	/**
	* @brief addValue method
	*
	* used to add a new value to the vector
	* will increase the vectors size if their is not enough room
	*
	* @return void
	* @param value -  constant Template containing value for the array
	*/

	void addValue(const T value)
	{
		vec.push_back(value);
	}




	/**
	* @brief removePostion method
	*
	* used to remove a position in the vector
	* moves all values in the array down by one and decresses size
	* returns true if value was changed and false if it was unsuccessful
	*
	* @return bool
	* @param postion - constant int containing position in array
	*/

	bool removePostion(const int postion)
	{
		if (postion >= 0 && postion < vec.size())
		{
			vec.erase(postion);
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	* @brief getSize method
	*
	* returns number of items in vector
	*
	* @return int
	*/

	int getSize() const
	{
		return vec.size();
	}

	/**
	* @brief overloaded = operator
	*
	* used to copy a vector in another vector
	* calls copy method
	*
	* @return Vector pointer - used to chain operator
	* @param vector -  constant vector containing position in array
	*/

	STLVector& operator = (const STLVector &vector)
	{
		vec = vector.vec;
		return *this;
	}
	/**
	* @brief overloaded const [] operator
	*
	* used to get a position in the vector
	* throws exeption if position out of bounds
	*
	* @return T - value at position
	* @param postion - constant int containing position in array
	*/

	const T & operator [] (const int postion) const
	{
		return vec.at(postion);
	}
	/**
	* @brief overloaded [] operator
	*
	* used to change the value of a position in the vector
	* throws exeption if position out of bounds
	*
	* @return T - value at position
	* @param postion -  constant int containing position in array
	*/
	T & operator [] (const int postion)
	{
		return vec.at(postion);
	}




	/* friend std::ostream& operator << (std::ostream &ostr, const Vector &vector)
	 {
		 ostr << "vec is stored at location: " << &(vector.vec)
		 << std::endl;
		 ostr << "vec points to location: " << vector.vec << std::endl;
		 ostr << "contents of location is: " << *vector.vec << std::endl;

		 return ostr;
	 } */

	 /**
	 * @brief clear method
	 *
	 * used to delete all data in a vector
	 * resets all values of a vector to its defult values
	 * @return void
	 */

	void clear()
	{
		vec.clear();
	}

private:

	/**
	* @brief increaseSize method
	*
	* used to increase size of the vector
	* will double the size of the vector while keeping all current values
	*
	* @return void
	*/



	/**
	* @brief copyVector method
	*
	* checks to see if the vector is empty
	* deletes the old array and sets the vectors values to the vector being passed in
	* sets the size of the vector and the amount of values equal to the new vector's values
	* returns true if it was compleated sucessfuly and false if it was not
	* @return bool
	* @param Vector - constant int containing position in array
	*/

	std::vector<T> vec;
};

#endif // VECTOR_H

