
#include "DataTime.h"

DateTime::DateTime()
{
	date.SetDay(0);
	date.SetMonth(0);
	date.SetYear(0);
	time.setHours(0);
	time.setMinutes(0);

}


DateTime::DateTime(Date dat, Time tim)
{
	date.SetDay(dat.GetDay());
	date.SetMonth(dat.GetMonth());
	date.SetYear(dat.GetYear());
	time.setHours(tim.getHours());
	time.setMinutes(tim.getMinutes());
}


Date DateTime::GetDate()
{
	return date;
}



void DateTime::SetDate(Date dat)
{
	date = dat;
}

Time DateTime::GetTime()
{
	return time;
}



void DateTime::SetTime(Time dat)
{
	time = dat;
}

// only checks the date so it can be used in the bst
bool DateTime::operator == (const DateTime& DateTime) const
{
	if (date == DateTime.date)
	{
		if (time == DateTime.time)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}
// only checks the date so it can be used in the bst
bool DateTime::operator < (const DateTime& DateTime) const
{
	if (date < DateTime.date)
	{
		return true;
	}
	else if (date == DateTime.date)
	{
		if (time < DateTime.time)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}

}

// only checks the date so it can be used in the bst
bool DateTime::operator > (const DateTime& DateTime) const
{

	if (date > DateTime.date)
	{
		return true;
	}
	else if (date == DateTime.date)
	{
		if (time > DateTime.time)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}


DateTime& DateTime::operator = (const DateTime& DateTime)
{
	date = DateTime.date;
	time = DateTime.time;
	return *this;
}


