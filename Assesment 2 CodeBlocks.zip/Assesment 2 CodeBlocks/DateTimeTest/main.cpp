#include <iostream>
#include "../DATE.h"
#include "../DataTime.h"
#include "../Time.h"
using namespace std;

int main()
{

    DateTime DateTi;
    Time tim(16,30);
    Date dat(16,3,2000);

    DateTime DateTim(dat,tim);
    DateTime dateTime[2];
    dateTime[0].SetDate(dat);
    dateTime[1].SetTime(tim);

    cout << DateTim.GetDate().getDate() << " " <<  DateTim.GetTime().getTime()  << endl;
    cout <<  dateTime[0].GetDate().getDate()  << " " <<   dateTime[1].GetTime().getTime() << endl;


    Time TimeOne(18, 12);
    Date DateOne(18, 12, 2000);
    DateTime dateTimeOne(DateOne,TimeOne);

    Date DateTwo(18, 11, 2000);
	Time TimeTwo(18, 11);
    DateTime dateTimeTwo(DateTwo,TimeTwo);

	Date DateThree(18, 12, 1900);
	Time TimeThree(19, 12);
    DateTime dateTimeThree(DateThree,TimeThree);

	Date DateFor(18, 12, 2000);
	Time TimeFor(18, 12);
    DateTime dateTimeFor(DateFor, TimeFor);

	if (dateTimeOne == dateTimeFor)
	{
		cout << "value the same " << endl;
	}

	if (dateTimeTwo == dateTimeThree)
	{
		cout << "value the same " << endl;
	}

	if (dateTimeTwo < dateTimeOne)
	{
		cout << "Greater " << endl;
	}

	if (dateTimeThree < dateTimeTwo)
	{
		cout << "Greater" << endl;
	}

	if (dateTimeFor < dateTimeThree)
	{
		cout << "Greater" << endl;
	}

	if (dateTimeOne > dateTimeTwo)
	{
		cout << "Lesser " << endl;
	}


    DateTi = dateTimeOne;

    cout << DateTi.GetDate().getDate() << " " << DateTi.GetTime().getTime() << endl;

}
