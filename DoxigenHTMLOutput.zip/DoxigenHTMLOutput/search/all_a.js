var searchData=
[
  ['node_42',['node',['../structtree_1_1node.html',1,'tree']]]
];
