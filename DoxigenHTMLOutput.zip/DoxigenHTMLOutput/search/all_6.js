var searchData=
[
  ['hours_32',['hours',['../class_time.html#aa207ff7d820b4c32f22e1474a931b195',1,'Time']]]
];
