var searchData=
[
  ['value_153',['value',['../structtree_1_1node.html#abe6e9b247e8decc4a9d8bccdabaf3ea4',1,'tree::node']]]
];
