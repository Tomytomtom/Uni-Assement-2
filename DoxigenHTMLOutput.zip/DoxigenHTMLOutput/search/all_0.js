var searchData=
[
  ['ambientairtemperature_0',['ambientAirTemperature',['../struct_wind_log_type.html#ab676f22897a07cd715ce29aec669a9c1',1,'WindLogType']]]
];
