var searchData=
[
  ['windlogmap_159',['windLogMap',['../main_8cpp.html#a6fa89946a9682d1b9e7d110a1616d1c8',1,'main.cpp']]],
  ['windlogvec_160',['windLogVec',['../main_8cpp.html#abe8d2adf18873899d4db93b5cb553fc4',1,'main.cpp']]]
];
